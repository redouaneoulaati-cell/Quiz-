QuizApp V2 - Gradle launcher

Included:
- gradlew
- gradlew.bat
- gradle/wrapper/gradle-wrapper.properties

The launcher downloads Gradle 8.9 automatically on the first build if it is not
already cached on the machine/runner. This keeps the repository usable without
installing Gradle globally.

GitHub Actions can run:
./gradlew assembleDebug
