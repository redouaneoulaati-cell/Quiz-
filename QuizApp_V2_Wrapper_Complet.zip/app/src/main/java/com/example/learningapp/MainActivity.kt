package com.example.learningapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup

class MainActivity : AppCompatActivity() {

    private lateinit var tvHighScore: TextView
    private lateinit var toggleDifficulty: MaterialButtonToggleGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvHighScore = findViewById(R.id.tvHighScore)
        toggleDifficulty = findViewById(R.id.toggleDifficulty)

        toggleDifficulty.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                displayHighScore(getSelectedDifficulty(checkedId))
            }
        }

        findViewById<Button>(R.id.btnStartQuiz).setOnClickListener {
            val difficulty = getSelectedDifficulty(toggleDifficulty.checkedButtonId)
            startActivity(Intent(this, QuizActivity::class.java).apply {
                putExtra("SELECTED_DIFFICULTY", difficulty)
            })
        }
    }

    override fun onResume() {
        super.onResume()
        displayHighScore(getSelectedDifficulty(toggleDifficulty.checkedButtonId))
    }

    private fun getSelectedDifficulty(id: Int): String = when (id) {
        R.id.btnMedium -> "MEDIUM"
        R.id.btnHard -> "HARD"
        else -> "EASY"
    }

    private fun displayHighScore(difficulty: String) {
        val prefs = getSharedPreferences("QuizPrefs", Context.MODE_PRIVATE)
        val score = prefs.getInt("HIGH_SCORE_$difficulty", 0)
        val total = prefs.getInt("MAX_QUESTIONS_$difficulty", 0)
        tvHighScore.text = if (total > 0) "$score / $total" else "0 / 0"
    }
}
