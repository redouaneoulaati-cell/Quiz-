package com.example.learningapp

data class Question(
    val category: String,
    val text: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val difficulty: String
)
