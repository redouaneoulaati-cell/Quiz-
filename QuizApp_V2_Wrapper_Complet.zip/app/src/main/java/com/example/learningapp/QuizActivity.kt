package com.example.learningapp

import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private val allQuestions = listOf(
        Question("Android", "Que veut dire APK ?",
            listOf("Android Package", "Android App", "Application Kernel", "Android Program"), 0, "EASY"),
        Question("Kotlin", "Quel mot-clé déclare une variable immuable ?",
            listOf("var", "val", "let", "static"), 1, "EASY"),
        Question("Android", "Quel composant est adapté aux listes performantes ?",
            listOf("TextView", "RecyclerView", "ImageView", "Button"), 1, "MEDIUM"),
        Question("Kotlin", "Quel opérateur permet un accès sécurisé à une valeur nullable ?",
            listOf("!!", "?.", "??", "::"), 1, "MEDIUM"),
        Question("Architecture", "Que signifie MVVM ?",
            listOf("Model View ViewModel", "Main View Vector", "Model Value Manager", "Mobile View Model"), 0, "HARD")
    )

    private lateinit var questionsList: List<Question>
    private lateinit var tvQuestionCount: TextView
    private lateinit var tvQuestionText: TextView
    private lateinit var tvTimer: TextView
    private lateinit var rgOptions: RadioGroup
    private lateinit var rbOption1: RadioButton
    private lateinit var rbOption2: RadioButton
    private lateinit var rbOption3: RadioButton
    private lateinit var rbOption4: RadioButton
    private lateinit var btnNext: Button

    private var currentQuestionIndex = 0
    private var score = 0
    private var selectedDifficulty = "EASY"
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        tvQuestionCount = findViewById(R.id.tvQuestionCount)
        tvQuestionText = findViewById(R.id.tvQuestionText)
        tvTimer = findViewById(R.id.tvTimer)
        rgOptions = findViewById(R.id.rgOptions)
        rbOption1 = findViewById(R.id.rbOption1)
        rbOption2 = findViewById(R.id.rbOption2)
        rbOption3 = findViewById(R.id.rbOption3)
        rbOption4 = findViewById(R.id.rbOption4)
        btnNext = findViewById(R.id.btnNext)

        selectedDifficulty = intent.getStringExtra("SELECTED_DIFFICULTY") ?: "EASY"
        questionsList = allQuestions.filter { it.difficulty == selectedDifficulty }

        if (questionsList.isEmpty()) questionsList = allQuestions
        questionsList = questionsList.shuffled()

        btnNext.setOnClickListener { validateAnswer() }
        loadQuestion()
    }

    private fun loadQuestion() {
        timer?.cancel()

        if (currentQuestionIndex >= questionsList.size) {
            finishQuiz()
            return
        }

        val q = questionsList[currentQuestionIndex]
        tvQuestionCount.text = "Question ${currentQuestionIndex + 1}/${questionsList.size}"
        tvQuestionText.text = q.text
        tvTimer.text = "⏱️ 15 s"

        val buttons = listOf(rbOption1, rbOption2, rbOption3, rbOption4)
        buttons.forEachIndexed { index, button ->
            if (index < q.options.size) {
                button.visibility = android.view.View.VISIBLE
                button.text = q.options[index]
            } else {
                button.visibility = android.view.View.GONE
            }
            button.isChecked = false
        }

        btnNext.text = if (currentQuestionIndex == questionsList.lastIndex) "Terminer" else "Suivant"
        startTimer()
    }

    private fun startTimer() {
        timer = object : CountDownTimer(15000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvTimer.text = "⏱️ ${millisUntilFinished / 1000 + 1} s"
            }

            override fun onFinish() {
                tvTimer.text = "⏱️ Temps écoulé"
                nextQuestion(false)
            }
        }.start()
    }

    private fun validateAnswer() {
        val checkedId = rgOptions.checkedRadioButtonId
        if (checkedId == -1) {
            Toast.makeText(this, "Sélectionne une réponse.", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedIndex = when (checkedId) {
            R.id.rbOption1 -> 0
            R.id.rbOption2 -> 1
            R.id.rbOption3 -> 2
            R.id.rbOption4 -> 3
            else -> -1
        }

        nextQuestion(selectedIndex == questionsList[currentQuestionIndex].correctAnswerIndex)
    }

    private fun nextQuestion(correct: Boolean) {
        timer?.cancel()
        if (correct) score++
        currentQuestionIndex++
        loadQuestion()
    }

    private fun finishQuiz() {
        saveHighScore()

        AlertDialog.Builder(this)
            .setTitle("🎉 Quiz terminé !")
            .setMessage("Ton score : $score / ${questionsList.size}")
            .setCancelable(false)
            .setPositiveButton("Rejouer") { _, _ ->
                currentQuestionIndex = 0
                score = 0
                questionsList = questionsList.shuffled()
                loadQuestion()
            }
            .setNegativeButton("Accueil") { _, _ -> finish() }
            .show()
    }

    private fun saveHighScore() {
        val prefs = getSharedPreferences("QuizPrefs", Context.MODE_PRIVATE)
        val key = "HIGH_SCORE_$selectedDifficulty"
        val maxKey = "MAX_QUESTIONS_$selectedDifficulty"
        val oldScore = prefs.getInt(key, 0)

        if (score > oldScore) {
            prefs.edit()
                .putInt(key, score)
                .putInt(maxKey, questionsList.size)
                .apply()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
